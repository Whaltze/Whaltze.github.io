"""Inspect/unlock local PDFs, keep originals, and verify rendered output."""
from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

import pypdfium2 as pdfium
from PIL import ImageChops
from pypdf import PdfReader, PdfWriter


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pdf_files(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf')


def read_pdf(path: Path, password: str = ''):
    reader = PdfReader(path)
    encrypted = reader.is_encrypted
    accepted = ''
    if encrypted and not reader.decrypt(''):
        if not password or not reader.decrypt(password):
            raise ValueError('需要有效的打开密码或所有者密码；本脚本不猜测密码')
        accepted = password
    return reader, encrypted, accepted


def first_page_text(path: Path, password: str = '') -> str:
    doc = pdfium.PdfDocument(path, password=password or None)
    try:
        page = doc[0]
        try:
            textpage = page.get_textpage()
            try:
                return textpage.get_text_range()
            finally:
                textpage.close()
        finally:
            page.close()
    finally:
        doc.close()


def text_warning(text: str) -> str | None:
    controls = sum(ord(c) < 32 and c not in '\r\n\t' for c in text)
    if controls > max(5, len(text) // 50):
        return '提取结果含大量控制字符：需检查字形映射，解除加密不会自动修复'
    if len(text.strip()) < 50:
        return '文本很少：需检查扫描图、轮廓文字或缺失文字层'
    return None


def compare_pages(source: Path, output: Path, password: str = '') -> int:
    before = pdfium.PdfDocument(source, password=password or None)
    after = pdfium.PdfDocument(output)
    try:
        if len(before) != len(after):
            raise ValueError('页数变化')
        for i in range(len(before)):
            p1, p2 = before[i], after[i]
            try:
                b1, b2 = p1.render(scale=1.25), p2.render(scale=1.25)
                try:
                    im1, im2 = b1.to_pil().convert('RGB'), b2.to_pil().convert('RGB')
                    if im1.size != im2.size or ImageChops.difference(im1, im2).getbbox():
                        raise ValueError(f'第 {i + 1} 页显示变化，请人工检查')
                finally:
                    b1.close()
                    b2.close()
            finally:
                p1.close()
                p2.close()
        return len(before)
    finally:
        before.close()
        after.close()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    inspect = sub.add_parser('inspect')
    inspect.add_argument('source', type=Path)
    unlock = sub.add_parser('unlock')
    unlock.add_argument('source', type=Path)
    unlock.add_argument('output', type=Path)
    unlock.add_argument('--password-prompt', action='store_true')
    args = parser.parse_args()
    source_root = args.source.resolve(strict=True)
    if not source_root.is_dir():
        parser.error('source 必须是目录')
    sources = pdf_files(source_root)
    if not sources:
        parser.error('目录内没有 PDF')
    password = getpass.getpass('已知密码（不会写入报告）：') if getattr(args, 'password_prompt', False) else ''
    if args.mode == 'unlock':
        output_root = args.output.resolve()
        if output_root.is_relative_to(source_root) or source_root.is_relative_to(output_root):
            parser.error('输入与输出目录必须互不包含，请使用并列目录')
        if output_root.exists():
            parser.error('输出目录已存在；请换一个新目录，避免覆盖')
        output_root.mkdir(parents=True)
        backup = output_root / 'originals.zip'
        with zipfile.ZipFile(backup, 'x', zipfile.ZIP_DEFLATED) as z:
            for path in sources:
                z.write(path, path.relative_to(source_root).as_posix())
        with zipfile.ZipFile(backup) as z:
            if z.testzip() is not None:
                raise ValueError('备份 ZIP 校验失败')
            for path in sources:
                if digest(z.read(path.relative_to(source_root).as_posix())) != digest(path.read_bytes()):
                    raise ValueError('备份内容与输入不一致')
    rows = []
    for path in sources:
        relative = path.relative_to(source_root)
        row = {'file': relative.as_posix(), 'source_sha256': digest(path.read_bytes())}
        try:
            reader, encrypted, accepted = read_pdf(path, password)
            row.update(encrypted_before=encrypted, pages=len(reader.pages))
            if encrypted:
                enc = reader.trailer['/Encrypt']
                row['encryption_parameters'] = {k: int(enc[k]) for k in ['/V', '/R', '/Length', '/P'] if k in enc}
            row['text_warning'] = text_warning(first_page_text(path, accepted))
            if args.mode == 'unlock':
                output = output_root / relative
                output.parent.mkdir(parents=True, exist_ok=True)
                if encrypted:
                    PdfWriter(clone_from=reader).write(output)
                else:
                    shutil.copy2(path, output)
                check = PdfReader(output)
                if check.is_encrypted or len(check.pages) != len(reader.pages):
                    raise ValueError('输出仍加密或页数不一致')
                row['render_verified_pages'] = compare_pages(path, output, accepted)
                row['encrypted_after'] = False
                row['output_sha256'] = digest(output.read_bytes())
            row['status'] = 'ok'
        except Exception as exc:
            row.update(status='needs_attention', reason=str(exc))
        rows.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)
    if args.mode == 'unlock':
        (output_root / 'report.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if all(r['status'] == 'ok' for r in rows) else 1


if __name__ == '__main__':
    raise SystemExit(main())
