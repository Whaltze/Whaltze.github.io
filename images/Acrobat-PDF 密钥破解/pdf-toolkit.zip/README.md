# Acrobat-PDF 密钥破解：配套脚本

这些脚本配合博客文章使用。Python 3.12.14、依赖版本见 requirements.txt。

在 PowerShell 中，把脚本与 requirements.txt 解压到工作目录，待处理 PDF 放在 input 子目录。

```powershell
py -3.12 -m venv .venv
$python = Join-Path $PWD '.venv\Scripts\python.exe'
& $python -m pip install -r .\requirements.txt
& $python .\pdf_batch_unlock.py inspect .\input
& $python .\pdf_batch_unlock.py unlock .\input .\output
```

输出目录必须尚不存在，且与输入目录互不包含。脚本保留输入，输出内建立 originals.zip，报告为 report.json。status 为 ok 仍需检查 text_warning；脚本不自动识别或修复所有异常字体。

有已知密码时使用 --password-prompt 交互输入。小范围候选恢复：

```powershell
& $python .\try_pdf_candidates.py .\locked.pdf .\candidates.txt .\unlocked.pdf
```

candidates.txt 使用 UTF-8，每行一个本人提供的候选，前后空格会保留。默认最多 1000 条候选。匹配后输出无加密副本，不在日志打印密码。候选全失败时退出码为 1。

repair_case_fontmap.py 和 case_fontmap.json 仅用于文章中那份原始特殊样本，先检查原件 SHA-256。映射已由 OCR 辅助和人工核对，不会给其他 PDF 自动生成映射：

```powershell
& $python .\repair_case_fontmap.py '.\input\2025年6月英语六级真题(第1套).pdf' .\case-repaired.pdf
```

重放后仍需独立核对页数、实际搜索与页面渲染。已转为路径的字形保留图形，隐藏文字层用于搜索，并不把图形变回普通文本。

project_result.json 记录原任务结果；rehearsal_result.json 记录本文脚本复现结果；article_qa.json 记录正文和资源检查。只包含文档名称和验证数据，未包含原始 PDF、真实密码、个人目录或第三方程序。

脚本为本次项目整理；第三方依赖遵循各自许可证。文章中 qpdf、Acrobat、John、Hashcat 的拓展用法核对了官方资料，未在本文环境实机运行。
