"""Try a small, explicit candidate list against your own password-protected PDF."""
import argparse
from pathlib import Path
from pypdf import PdfReader, PdfWriter


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('candidates', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--limit', type=int, default=1000)
    args = parser.parse_args()
    if args.output.exists() or args.output.resolve() == args.source.resolve():
        parser.error('输出必须是新的文件路径')
    lines = args.candidates.read_text(encoding='utf-8-sig').splitlines()
    candidates = list(dict.fromkeys(line for line in lines if line))
    if not 1 <= len(candidates) <= args.limit <= 10000:
        parser.error('请使用 1 至 limit 条明确候选；limit 最大为 10000')
    for index, candidate in enumerate(candidates, 1):
        reader = PdfReader(args.source)
        if not reader.is_encrypted:
            parser.error('输入没有加密，无需尝试密码')
        if reader.decrypt(candidate):
            args.output.parent.mkdir(parents=True, exist_ok=True)
            PdfWriter(clone_from=reader).write(args.output)
            check = PdfReader(args.output)
            if check.is_encrypted or len(check.pages) != len(reader.pages):
                raise ValueError('输出校验失败')
            print(f'第 {index} 条候选通过，已保存无加密副本；未在日志显示密码')
            return 0
    print('候选均未匹配；这只说明当前候选集合未命中')
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
