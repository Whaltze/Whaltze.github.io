"""Replay the reviewed glyph mapping for the exact PDF sample in this article."""
import argparse
import hashlib
import json
from io import BytesIO
from pathlib import Path
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, NameObject
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas


def make_cmap(mapping):
    entries = [f'<{int(code):02X}> <{text.encode("utf-16-be").hex().upper()}>' for code, text in mapping.items()]
    lines = ['/CIDInit /ProcSet findresource begin', '12 dict begin', 'begincmap',
             '/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def',
             '/CMapName /RecoveredUnicode def', '/CMapType 2 def',
             '1 begincodespacerange', '<00> <FF>', 'endcodespacerange']
    for i in range(0, len(entries), 100):
        chunk = entries[i:i + 100]
        lines += [f'{len(chunk)} beginbfchar', *chunk, 'endbfchar']
    lines += ['endcmap', 'CMapName currentdict /CMap defineresource pop', 'end', 'end']
    stream = DecodedStreamObject()
    stream.set_data(('\n'.join(lines) + '\n').encode('ascii'))
    return stream


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--mapping', type=Path, default=Path(__file__).with_name('case_fontmap.json'))
    args = parser.parse_args()
    data = json.loads(args.mapping.read_text(encoding='utf-8'))
    if hashlib.sha256(args.source.read_bytes()).hexdigest() != data['source_sha256']:
        parser.error('输入与本文原始样本的 SHA-256 不符，不能套用这份字形映射')
    if args.output.exists() or args.output.resolve() == args.source.resolve():
        parser.error('输出必须是新文件，禁止覆盖源文件')
    reader = PdfReader(args.source)
    writer = PdfWriter(clone_from=reader)
    for item in data['fonts']:
        page = writer.pages[item['page_index']]
        font = page['/Resources']['/Font'][item['resource_name']]
        if font['/Subtype'] != '/Type3':
            raise ValueError('字体类型与样本不符')
        font[NameObject('/ToUnicode')] = writer._add_object(make_cmap(item['mapping']))
    pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
    stream = BytesIO()
    width, height = map(float, writer.pages[0].mediabox[2:])
    c = canvas.Canvas(stream, pagesize=(width, height))
    text = c.beginText(114.87, 788.30)
    text.setTextRenderMode(3)
    text.setFont('STSong-Light', 17.98)
    text.textOut(data['searchable_title'])
    c.drawText(text)
    c.save()
    stream.seek(0)
    writer.pages[0].merge_page(PdfReader(stream).pages[0])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    writer.write(args.output)
    print('样本文字映射和标题搜索层已恢复；请另行验证渲染与搜索')


if __name__ == '__main__':
    main()
